package io.github.j_yuhanwang.food_ordering_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrderingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
